# Infinite-Runner
A 2D endless running game made with Unity Game Engine.
