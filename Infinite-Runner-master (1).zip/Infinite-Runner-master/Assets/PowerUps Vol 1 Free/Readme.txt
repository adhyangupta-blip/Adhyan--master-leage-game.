-------------------------------
--Mobile Power Ups Free Vol 1--
-------------------------------

This free collection of 3D power-ups includes 20 different power-ups.
All power-ups are optimized for mobile and browser games.

FREE VERSION:
The free version comes with the full set of meshes and the basic diffuse textures.

The paid version has three different color/texture variations for each power up and comes alpha masks for reflections, a custom cubemap, normal maps, particle effects and a script component to animate your power ups in different ways.









---------------------------------
--Mobile Power Ups Vol 1 (PRO) --
---------------------------------

This collection of 3D power-ups includes 20 different power-ups in three different variations.
Includes a custom cubemap, normal maps and particle effects. All power-ups are optimized for mobile and browser games.



1.0 Power Up Animation Component
--------------------------------

If you want to use this script elsewhere, add the component below the top GameObject. That way it will get transformation offset from the original values. Make sure the GameObject you add this script does not already have an offset.

We have included a few examples different types of animations. You can either use one, or all animation options at once! 

You can find it in this scene under "Animation Examples":
\PowerUps Vol1\Assets\PowerUps Vol 1\Scenes\DemoScene.unity



Options:
--------

->Rotation Speed In Degree
Make your power ups spin into any direction!
One value per axis. A higher value means a higher rotation speed. Negative values will make the power up spin into the opposite direction.

->Scale Min
Minimum scale. 1 is the original size. Negative scale is allowed.

->Scale Max
Maximum scale. 1 is the original size. Negative scale is allowed.


->Scale Cycle Duration
Time in seconds how long the cycle duration takes.


->YOffset Amplitude
Height offset from the original position of the power up. (Up and down!)


->YOffset Cycle Duration
Time in seconds how long the cycle duration takes.